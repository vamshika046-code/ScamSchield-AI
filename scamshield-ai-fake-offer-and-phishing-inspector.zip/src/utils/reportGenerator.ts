import { ThreatAnalysisResult } from "../types";

export function generateMarkdownReport(result: ThreatAnalysisResult, inputSnippet: string): string {
  const timestamp = new Date(result.analyzedAt).toLocaleString();
  
  return `# ScamShield AI Threat Audit Report
**Inspection Date:** ${timestamp}  
**Classification:** ${result.scamCategory}  
**Overall Threat Index:** ${result.threatIndex} / 100  
**Risk Level:** ${result.riskLevel}  

---

## 1. Executive Summary
**${result.verdictTitle}**  
${result.summary}

---

## 2. Key Fraud & Phishing Indicators
${result.indicators.map(ind => `- **[${ind.present ? 'DETECTED' : 'CLEARED'}] ${ind.indicator}** (Score Impact: +${ind.scoreImpact}): ${ind.observation}`).join('\n')}

---

## 3. Flagged Suspicious Phrases & Red Flags
${result.highlightedPhrases.length === 0 ? '_No critical red-flag phrases identified._' : result.highlightedPhrases.map((phrase, idx) => `
### ${idx + 1}. "${phrase.phrase}"
- **Category:** ${phrase.category}
- **Severity:** ${phrase.severity.toUpperCase()}
- **Why this is a red flag:** ${phrase.explanation}
`).join('\n')}

---

## 4. URL & Email Domain Investigation
### URL Analysis
- **Detected URL:** ${result.urlFindings.detectedUrl || 'None specified'}
- **Verdict:** ${result.urlFindings.verdict.toUpperCase()}
- **Analysis:** ${result.urlFindings.domainAnalysis}
${result.urlFindings.details.map(d => `  - ${d}`).join('\n')}

### Recruiter Email Analysis
- **Detected Email:** ${result.emailFindings.detectedEmail || 'None specified'}
- **Verdict:** ${result.emailFindings.verdict.toUpperCase()}
- **Analysis:** ${result.emailFindings.domainAnalysis}
${result.emailFindings.details.map(d => `  - ${d}`).join('\n')}

---

## 5. What Should I Do Now? (Security Action Plan)

### Immediate Containment Steps
${result.actionPlan.immediateSteps.map(step => `1. ${step}`).join('\n')}

### Safe Verification Protocol
${result.actionPlan.safeVerificationSteps.map(step => `- [ ] ${step}`).join('\n')}

### Prohibited Actions (What NOT to do)
${result.actionPlan.whatNotToDo.map(warn => `- **DO NOT:** ${warn}`).join('\n')}

### Official Incident Reporting Portals
${result.actionPlan.reportingChannels.map(ch => `- **${ch.name}**: ${ch.description} [${ch.url}](${ch.url})`).join('\n')}

---

## 6. Original Scanned Content Excerpt
\`\`\`text
${inputSnippet.slice(0, 1500)}${inputSnippet.length > 1500 ? '\n... [truncated for report length]' : ''}
\`\`\`

---
*Report generated securely by ScamShield AI Fake Offer and Phishing Inspector.*
`;
}

export function generateHtmlReport(result: ThreatAnalysisResult, inputSnippet: string): string {
  const timestamp = new Date(result.analyzedAt).toLocaleString();
  
  const riskColor = 
    result.riskLevel === 'CRITICAL' ? '#dc2626' :
    result.riskLevel === 'HIGH' ? '#ea580c' :
    result.riskLevel === 'MODERATE' ? '#d97706' :
    result.riskLevel === 'LOW' ? '#2563eb' : '#16a34a';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Threat Audit Report - ${result.verdictTitle}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; color: #1e293b; background: #f8fafc; padding: 40px; margin: 0; }
    .container { max-width: 850px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 40px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #e2e8f0; padding-bottom: 24px; margin-bottom: 28px; }
    .title { font-size: 24px; font-weight: 700; color: #0f172a; margin: 0 0 6px 0; }
    .subtitle { font-size: 13px; color: #64748b; margin: 0; }
    .badge { display: inline-block; padding: 6px 14px; border-radius: 9999px; font-weight: 700; font-size: 13px; color: #fff; background: ${riskColor}; }
    .score-box { background: #f1f5f9; border-radius: 8px; padding: 20px; margin-bottom: 28px; display: flex; align-items: center; justify-content: space-between; border-left: 6px solid ${riskColor}; }
    .score-number { font-size: 36px; font-weight: 800; color: #0f172a; }
    .section-title { font-size: 17px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-top: 32px; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.05em; }
    .phrase-card { background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 14px; margin-bottom: 12px; }
    .phrase-text { font-weight: 700; color: #991b1b; font-size: 14px; margin-bottom: 4px; }
    .phrase-meta { font-size: 12px; color: #7f1d1d; margin-bottom: 6px; }
    .phrase-desc { font-size: 13px; color: #334155; margin: 0; }
    .checklist { list-style-type: none; padding-left: 0; }
    .checklist li { position: relative; padding-left: 28px; margin-bottom: 8px; font-size: 14px; }
    .checklist li::before { content: "✓"; position: absolute; left: 0; top: 0; color: #16a34a; font-weight: bold; }
    .warning-list { list-style-type: none; padding-left: 0; }
    .warning-list li { position: relative; padding-left: 28px; margin-bottom: 8px; font-size: 14px; color: #991b1b; }
    .warning-list li::before { content: "✕"; position: absolute; left: 0; top: 0; color: #dc2626; font-weight: bold; }
    .code-box { background: #0f172a; color: #f8fafc; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 12px; overflow-x: auto; white-space: pre-wrap; word-break: break-word; max-height: 250px; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #94a3b8; text-align: center; }
    @media print {
      body { background: #fff; padding: 0; }
      .container { border: none; box-shadow: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div>
        <h1 class="title">ScamShield AI Threat Audit Report</h1>
        <p class="subtitle">Generated on ${timestamp} | Classification: <strong>${result.scamCategory}</strong></p>
      </div>
      <div>
        <span class="badge">${result.riskLevel} THREAT</span>
      </div>
    </div>

    <div class="score-box">
      <div>
        <div style="font-size: 12px; text-transform: uppercase; color: #64748b; font-weight: 600;">Scam Threat Index</div>
        <div class="score-number">${result.threatIndex} <span style="font-size: 18px; color: #64748b; font-weight: 400;">/ 100</span></div>
      </div>
      <div style="max-width: 480px; text-align: right;">
        <div style="font-weight: 700; color: #0f172a; font-size: 15px;">${result.verdictTitle}</div>
        <div style="font-size: 13px; color: #475569; margin-top: 4px;">${result.summary}</div>
      </div>
    </div>

    <div class="section-title">Suspicious Red-Flag Phrases Detected</div>
    ${result.highlightedPhrases.length === 0 ? '<p style="font-size: 13px; color: #64748b;">No high-risk phrase patterns flagged.</p>' : 
      result.highlightedPhrases.map(p => `
        <div class="phrase-card">
          <div class="phrase-text">"${escapeHtml(p.phrase)}"</div>
          <div class="phrase-meta"><strong>Category:</strong> ${escapeHtml(p.category)} &bull; <strong>Severity:</strong> ${p.severity.toUpperCase()}</div>
          <p class="phrase-desc">${escapeHtml(p.explanation)}</p>
        </div>
      `).join('')
    }

    <div class="section-title">Domain & Contact Findings</div>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px;">
      <div style="background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <div style="font-weight: 700; font-size: 13px; margin-bottom: 4px;">URL / Web Link</div>
        <div style="font-size: 12px; color: #64748b; word-break: break-all; margin-bottom: 8px;">${result.urlFindings.detectedUrl || 'Not specified'}</div>
        <div style="font-size: 13px; color: #334155;">${escapeHtml(result.urlFindings.domainAnalysis)}</div>
      </div>
      <div style="background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <div style="font-weight: 700; font-size: 13px; margin-bottom: 4px;">Sender / Recruiter Email</div>
        <div style="font-size: 12px; color: #64748b; word-break: break-all; margin-bottom: 8px;">${result.emailFindings.detectedEmail || 'Not specified'}</div>
        <div style="font-size: 13px; color: #334155;">${escapeHtml(result.emailFindings.domainAnalysis)}</div>
      </div>
    </div>

    <div class="section-title">What Should I Do Now? (Security Action Plan)</div>
    <div style="margin-bottom: 16px;">
      <strong style="font-size: 14px; color: #0f172a;">Immediate Containment Steps:</strong>
      <ul class="checklist">
        ${result.actionPlan.immediateSteps.map(step => `<li>${escapeHtml(step)}</li>`).join('')}
      </ul>
    </div>

    <div style="margin-bottom: 16px;">
      <strong style="font-size: 14px; color: #0f172a;">Safe Independent Verification Protocol:</strong>
      <ul class="checklist">
        ${result.actionPlan.safeVerificationSteps.map(step => `<li>${escapeHtml(step)}</li>`).join('')}
      </ul>
    </div>

    <div style="margin-bottom: 16px;">
      <strong style="font-size: 14px; color: #991b1b;">Critical Prohibitions (Never Do This):</strong>
      <ul class="warning-list">
        ${result.actionPlan.whatNotToDo.map(warn => `<li>${escapeHtml(warn)}</li>`).join('')}
      </ul>
    </div>

    <div class="section-title">Official Incident Reporting Channels</div>
    <ul style="font-size: 13px; color: #334155; line-height: 1.6;">
      ${result.actionPlan.reportingChannels.map(ch => `<li><strong>${escapeHtml(ch.name)}</strong>: ${escapeHtml(ch.description)} (<a href="${ch.url}" target="_blank" rel="noopener noreferrer">${ch.url}</a>)</li>`).join('')}
    </ul>

    <div class="section-title">Original Scanned Material</div>
    <div class="code-box">${escapeHtml(inputSnippet.slice(0, 1500))}${inputSnippet.length > 1500 ? '\n... [truncated]' : ''}</div>

    <div class="footer">
      This automated threat analysis report was compiled by ScamShield AI Fake Offer and Phishing Inspector.<br>
      Always verify independently with corporate HR and official security teams.
    </div>
  </div>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
