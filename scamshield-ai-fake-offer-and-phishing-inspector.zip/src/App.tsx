import { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { InputPanel } from './components/InputPanel';
import { ThreatIndexGauge } from './components/ThreatIndexGauge';
import { HighlightedPhrases } from './components/HighlightedPhrases';
import { DomainEmailAnalysis } from './components/DomainEmailAnalysis';
import { ActionPlanView } from './components/ActionPlanView';
import { ReportModal } from './components/ReportModal';
import { ThreatAnalysisResult } from './types';
import { SAMPLE_CASES } from './data/sampleScams';
import { ShieldCheck, ShieldAlert, Sparkles, AlertCircle, RefreshCw, Lock } from 'lucide-react';

const INITIAL_PROMPT_TEXT = "Congratulations! You are selected for a remote data entry position. A cashier's check of $4,850 will be sent to you for home equipment. Contact our recruiter on Telegram at ApexHR to complete the process.";

export default function App() {
  const [messageText, setMessageText] = useState(INITIAL_PROMPT_TEXT);
  const [recruiterEmail, setRecruiterEmail] = useState('');
  const [urlOrDomain, setUrlOrDomain] = useState('');

  const [isScanning, setIsScanning] = useState(false);
  const [scanStep, setScanStep] = useState('Initiating security inspection...');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ThreatAnalysisResult | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);

  const resultsRef = useRef<HTMLDivElement>(null);
  const hasAutoScannedRef = useRef(false);

  const handleScan = async (textOverride?: string, emailOverride?: string, urlOverride?: string) => {
    const text = textOverride !== undefined ? textOverride : messageText;
    const email = emailOverride !== undefined ? emailOverride : recruiterEmail;
    const url = urlOverride !== undefined ? urlOverride : urlOrDomain;

    if (!text.trim()) {
      setError('Please paste a suspicious message, email, or offer letter to analyze.');
      return;
    }

    setError(null);
    setIsScanning(true);
    setScanStep('Analyzing linguistic patterns and urgency markers...');

    const stepInterval = setInterval(() => {
      setScanStep((prev) => {
        if (prev.includes('linguistic')) return 'Inspecting sender domains and web redirects...';
        if (prev.includes('sender domains')) return 'Cross-referencing advance-fee and equipment check fraud models...';
        if (prev.includes('advance-fee')) return 'Synthesizing threat index and containment action plan with Gemini...';
        return 'Compiling threat assessment report...';
      });
    }, 900);

    try {
      const response = await fetch('/api/scan-threats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messageText: text,
          recruiterEmail: email.trim() || undefined,
          urlOrDomain: url.trim() || undefined
        })
      });

      clearInterval(stepInterval);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const data: ThreatAnalysisResult = await response.json();
      setResult(data);

      // Smooth scroll to results if user initiated after mount
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err: any) {
      clearInterval(stepInterval);
      console.error('Scan error:', err);
      setError(err?.message || 'An unexpected error occurred during threat inspection. Please try again.');
    } finally {
      setIsScanning(false);
    }
  };

  // Automatically perform scan on initial load for the user's requested message
  useEffect(() => {
    if (!hasAutoScannedRef.current && INITIAL_PROMPT_TEXT) {
      hasAutoScannedRef.current = true;
      handleScan(INITIAL_PROMPT_TEXT, '', '');
    }
  }, []);

  const handleLoadFirstSample = () => {
    const sample = SAMPLE_CASES[0];
    setMessageText(sample.text);
    setRecruiterEmail(sample.recruiterEmail || '');
    setUrlOrDomain(sample.urlOrDomain || '');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased selection:bg-amber-200 selection:text-amber-950 font-sans">
      <Header />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Intro Hero Badge & Title */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 text-amber-400 text-xs font-semibold shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>AI-Powered Fraud Intelligence & Threat Verification</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            ScamShield AI Fake Offer & Phishing Inspector
          </h1>

          <p className="text-sm text-slate-600 leading-relaxed">
            Verify suspicious job offers, cashier check advance notices, cold WhatsApp recruiter chats, and spoofed payroll emails before exposing your identity or bank accounts.
          </p>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start justify-between gap-3 animate-in fade-in">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold">Inspection Error: </strong>
                <span>{error}</span>
              </div>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-rose-600 hover:text-rose-900 font-bold px-2 py-0.5 rounded hover:bg-rose-100"
            >
              ✕
            </button>
          </div>
        )}

        {/* Input Form Panel */}
        <InputPanel
          messageText={messageText}
          setMessageText={setMessageText}
          recruiterEmail={recruiterEmail}
          setRecruiterEmail={setRecruiterEmail}
          urlOrDomain={urlOrDomain}
          setUrlOrDomain={setUrlOrDomain}
          onScan={handleScan}
          isScanning={isScanning}
        />

        {/* Scanning in-progress animated state */}
        {isScanning && (
          <div className="p-8 bg-white rounded-2xl border border-slate-200 shadow-sm text-center space-y-4 animate-pulse">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center mx-auto shadow-md">
              <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Conducting In-Depth Threat Audit...
              </h3>
              <p className="text-xs font-mono text-amber-700 mt-1">
                {scanStep}
              </p>
            </div>
            <div className="max-w-md mx-auto h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 rounded-full animate-[indeterminate_1.5s_infinite_linear]" style={{ width: '60%' }} />
            </div>
          </div>
        )}

        {/* Results Container */}
        {result && (
          <div ref={resultsRef} className="space-y-6 pt-4 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                <h2 className="text-lg font-bold text-slate-900">
                  Security Inspection Findings
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                Analyzed: {new Date(result.analyzedAt).toLocaleTimeString()}
              </span>
            </div>

            {/* Threat Index Gauge & Verdict Card */}
            <ThreatIndexGauge
              result={result}
              onOpenReport={() => setShowReportModal(true)}
            />

            {/* Suspicious Highlighted Phrases */}
            <HighlightedPhrases
              phrases={result.highlightedPhrases}
              originalText={messageText}
            />

            {/* Domain & Email Findings */}
            <DomainEmailAnalysis
              urlFindings={result.urlFindings}
              emailFindings={result.emailFindings}
            />

            {/* Clear Action Plan & Containment Steps */}
            <ActionPlanView
              actionPlan={result.actionPlan}
              onOpenReport={() => setShowReportModal(true)}
            />
          </div>
        )}

        {/* Initial Empty / Prompt State */}
        {!result && !isScanning && (
          <div className="p-8 bg-white/70 rounded-2xl border border-slate-200/90 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200/60">
              <ShieldAlert className="w-6 h-6 text-amber-600" />
            </div>
            <div className="max-w-md mx-auto">
              <h3 className="text-sm font-bold text-slate-900">
                Ready to Inspect Suspect Outreach
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Paste any unsolicited message, job offer, or email above. Or click below to test with a simulated fake equipment check scam.
              </p>
            </div>
            <div>
              <button
                id="btn-load-empty-sample"
                onClick={handleLoadFirstSample}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Try Example: Fake Equipment Check Scam</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Report Modal */}
      {result && (
        <ReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          result={result}
          inputSnippet={messageText}
        />
      )}

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">ScamShield AI</span>
            <span>&bull;</span>
            <span>Fake Offer & Phishing Intelligence Inspector</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-emerald-700">
              <Lock className="w-3 h-3 text-emerald-600" />
              Zero Browser Key Exposure
            </span>
            <span>&bull;</span>
            <span>Educational & Preventive Security Tool</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
