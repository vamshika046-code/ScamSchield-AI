import { useState } from 'react';
import { HighlightedPhrase } from '../types';
import { AlertCircle, Tag, Eye, ListFilter, Sparkles } from 'lucide-react';

interface HighlightedPhrasesProps {
  phrases: HighlightedPhrase[];
  originalText: string;
}

export function HighlightedPhrases({ phrases, originalText }: HighlightedPhrasesProps) {
  const [activeTab, setActiveTab] = useState<'cards' | 'context'>('cards');
  const [selectedPhrase, setSelectedPhrase] = useState<HighlightedPhrase | null>(null);

  // Render original text with phrases highlighted
  const renderHighlightedContext = () => {
    if (!originalText) return null;
    if (phrases.length === 0) {
      return (
        <div className="p-4 bg-slate-50 rounded-xl text-xs text-slate-600 font-mono whitespace-pre-wrap leading-relaxed">
          {originalText}
        </div>
      );
    }

    // Sort phrases by appearance in text
    let segments: Array<{ text: string; phraseObj?: HighlightedPhrase }> = [{ text: originalText }];

    phrases.forEach((phraseObj) => {
      const phraseToMatch = phraseObj.phrase.trim();
      if (!phraseToMatch) return;

      const newSegments: Array<{ text: string; phraseObj?: HighlightedPhrase }> = [];

      segments.forEach((seg) => {
        if (seg.phraseObj) {
          // Already matched
          newSegments.push(seg);
          return;
        }

        const lowerSegText = seg.text.toLowerCase();
        const lowerMatch = phraseToMatch.toLowerCase();
        let startIndex = lowerSegText.indexOf(lowerMatch);

        if (startIndex === -1) {
          newSegments.push(seg);
          return;
        }

        let currText = seg.text;
        while (startIndex !== -1) {
          const before = currText.substring(0, startIndex);
          const matched = currText.substring(startIndex, startIndex + phraseToMatch.length);
          currText = currText.substring(startIndex + phraseToMatch.length);

          if (before) newSegments.push({ text: before });
          newSegments.push({ text: matched, phraseObj });

          startIndex = currText.toLowerCase().indexOf(lowerMatch);
        }

        if (currText) newSegments.push({ text: currText });
      });

      segments = newSegments;
    });

    return (
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-mono whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
        {segments.map((seg, idx) => {
          if (!seg.phraseObj) {
            return <span key={idx}>{seg.text}</span>;
          }

          const isSelected = selectedPhrase?.phrase === seg.phraseObj.phrase;
          const bgClass =
            seg.phraseObj.severity === 'high'
              ? 'bg-rose-200 text-rose-950 border-b-2 border-rose-500 hover:bg-rose-300'
              : seg.phraseObj.severity === 'medium'
              ? 'bg-amber-200 text-amber-950 border-b-2 border-amber-500 hover:bg-amber-300'
              : 'bg-yellow-200 text-yellow-950 border-b-2 border-yellow-500 hover:bg-yellow-300';

          return (
            <mark
              key={idx}
              onClick={() => setSelectedPhrase(seg.phraseObj || null)}
              className={`px-1 py-0.5 rounded cursor-pointer transition-colors ${bgClass} ${
                isSelected ? 'ring-2 ring-slate-900 ring-offset-1 font-bold' : ''
              }`}
              title={`Click to inspect flag: ${seg.phraseObj.category}`}
            >
              {seg.text}
            </mark>
          );
        })}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6">
      {/* Header and View Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <h3 className="text-base font-bold text-slate-900">
              Suspicious Highlighted Phrases & Red Flags
            </h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700">
              {phrases.length} flagged
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Key linguistic triggers, financial traps, or behavioral coercion markers identified by Gemini.
          </p>
        </div>

        <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200/80 self-start sm:self-center">
          <button
            id="btn-tab-phrase-cards"
            onClick={() => setActiveTab('cards')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'cards'
                ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ListFilter className="w-3.5 h-3.5" />
            Flag List
          </button>
          <button
            id="btn-tab-phrase-context"
            onClick={() => setActiveTab('context')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'context'
                ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            In-Context Highlighting
          </button>
        </div>
      </div>

      {phrases.length === 0 ? (
        <div className="text-center py-8 bg-slate-50 rounded-xl border border-slate-200/80">
          <Sparkles className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-800">No critical scam phrases identified</p>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            The scanned content did not match known high-risk phrases, though sender identity and URLs should still be independently confirmed.
          </p>
        </div>
      ) : activeTab === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {phrases.map((item, idx) => {
            const severityColor =
              item.severity === 'high'
                ? 'border-rose-200 bg-rose-50/50 hover:bg-rose-50'
                : item.severity === 'medium'
                ? 'border-amber-200 bg-amber-50/40 hover:bg-amber-50'
                : 'border-slate-200 bg-slate-50/60 hover:bg-slate-50';

            const badgeColor =
              item.severity === 'high'
                ? 'bg-rose-100 text-rose-800 border-rose-200'
                : item.severity === 'medium'
                ? 'bg-amber-100 text-amber-800 border-amber-200'
                : 'bg-slate-200 text-slate-700 border-slate-300';

            return (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border ${severityColor} transition-all flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-white/80 px-2 py-0.5 rounded-md border border-slate-200">
                      <Tag className="w-3 h-3 text-slate-500" />
                      {item.category}
                    </span>
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${badgeColor}`}>
                      {item.severity} Risk
                    </span>
                  </div>

                  <div className="mb-2">
                    <span className="text-xs font-mono font-bold text-slate-900 bg-white px-2 py-1 rounded border border-slate-200/80 inline-block shadow-2xs">
                      "{item.phrase}"
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.explanation}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div>
          {renderHighlightedContext()}

          {/* Selected Phrase Detail Drawer / Card */}
          {selectedPhrase && (
            <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start justify-between gap-3 animate-in fade-in duration-150">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-amber-900">
                    Inspecting: "{selectedPhrase.phrase}"
                  </span>
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-amber-200 text-amber-900">
                    {selectedPhrase.category} &bull; {selectedPhrase.severity} risk
                  </span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  {selectedPhrase.explanation}
                </p>
              </div>
              <button
                onClick={() => setSelectedPhrase(null)}
                className="text-xs text-amber-700 hover:text-amber-900 font-semibold px-2 py-1 rounded hover:bg-amber-100"
              >
                Dismiss
              </button>
            </div>
          )}

          <div className="flex items-center justify-between text-[11px] text-slate-600 mt-2 px-1">
            <span>Click any highlighted phrase to preview its fraud explanation</span>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-rose-300 inline-block" /> High Risk
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-amber-300 inline-block" /> Moderate Risk
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
