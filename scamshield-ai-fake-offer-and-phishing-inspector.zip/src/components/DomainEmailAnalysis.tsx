import { Globe, Mail, ShieldAlert, ShieldCheck, HelpCircle, ExternalLink } from 'lucide-react';
import { UrlFindings, EmailFindings } from '../types';

interface DomainEmailAnalysisProps {
  urlFindings: UrlFindings;
  emailFindings: EmailFindings;
}

export function DomainEmailAnalysis({ urlFindings, emailFindings }: DomainEmailAnalysisProps) {
  const getVerdictBadge = (verdict: string) => {
    switch (verdict.toLowerCase()) {
      case 'malicious':
      case 'suspicious':
      case 'spoofed':
        return {
          bg: 'bg-rose-100 text-rose-800 border-rose-200',
          icon: <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />,
          label: verdict.toUpperCase()
        };
      case 'safe':
        return {
          bg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />,
          label: 'LEGITIMATE PATTERN'
        };
      case 'unverified':
      default:
        return {
          bg: 'bg-amber-100 text-amber-800 border-amber-200',
          icon: <HelpCircle className="w-3.5 h-3.5 text-amber-600" />,
          label: 'REQUIRES VERIFICATION'
        };
    }
  };

  const urlBadge = getVerdictBadge(urlFindings.verdict);
  const emailBadge = getVerdictBadge(emailFindings.verdict);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6">
      <div className="mb-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Globe className="w-4 h-4 text-sky-600" />
          URL & Recruiter Email Domain Investigation
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Domain provenance, impersonation risks, free mailer spoofing, and hosting anomalies.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* URL Card */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                Web Portal / Link Analysis
              </span>
              <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${urlBadge.bg}`}>
                {urlBadge.icon}
                {urlBadge.label}
              </span>
            </div>

            <div className="mb-3">
              <div className="text-[11px] text-slate-600 font-medium">Target URL:</div>
              <div className="text-xs font-mono font-semibold text-slate-900 bg-white p-2 rounded-lg border border-slate-200 break-all select-all">
                {urlFindings.detectedUrl || 'No external URL detected in text or inputs.'}
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed mb-3">
              {urlFindings.domainAnalysis}
            </p>

            {urlFindings.details && urlFindings.details.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-slate-200/80">
                {urlFindings.details.map((detail, idx) => (
                  <div key={idx} className="text-xs text-slate-600 flex items-start gap-1.5">
                    <span className="text-slate-400 font-bold">&bull;</span>
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 text-[11px] text-slate-600 flex items-center justify-between">
            <span>Always manually re-type employer domains</span>
            <span className="font-semibold text-slate-700">Never click blind links</span>
          </div>
        </div>

        {/* Email Card */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-slate-500" />
                Sender / Recruiter Address
              </span>
              <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${emailBadge.bg}`}>
                {emailBadge.icon}
                {emailBadge.label}
              </span>
            </div>

            <div className="mb-3">
              <div className="text-[11px] text-slate-600 font-medium">Inspected Email:</div>
              <div className="text-xs font-mono font-semibold text-slate-900 bg-white p-2 rounded-lg border border-slate-200 break-all select-all">
                {emailFindings.detectedEmail || 'No sender email provided or detected.'}
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed mb-3">
              {emailFindings.domainAnalysis}
            </p>

            {emailFindings.details && emailFindings.details.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-slate-200/80">
                {emailFindings.details.map((detail, idx) => (
                  <div key={idx} className="text-xs text-slate-600 flex items-start gap-1.5">
                    <span className="text-slate-400 font-bold">&bull;</span>
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200/60 text-[11px] text-slate-600 flex items-center justify-between">
            <span>Free mailboxes (@gmail) represent 85%+ of job scams</span>
            <span className="font-semibold text-slate-700">Check MX records</span>
          </div>
        </div>
      </div>
    </div>
  );
}
