import React, { useState } from 'react';
import { Shield, Sparkles, Mail, Globe, ArrowRight, Trash2, FileText, CheckCircle } from 'lucide-react';
import { SAMPLE_CASES, SampleCase } from '../data/sampleScams';

interface InputPanelProps {
  messageText: string;
  setMessageText: (val: string) => void;
  recruiterEmail: string;
  setRecruiterEmail: (val: string) => void;
  urlOrDomain: string;
  setUrlOrDomain: (val: string) => void;
  onScan: () => void;
  isScanning: boolean;
}

export function InputPanel({
  messageText,
  setMessageText,
  recruiterEmail,
  setRecruiterEmail,
  urlOrDomain,
  setUrlOrDomain,
  onScan,
  isScanning
}: InputPanelProps) {
  const [activeSampleId, setActiveSampleId] = useState<string | null>(null);

  const handleSelectSample = (sample: SampleCase) => {
    setActiveSampleId(sample.id);
    setMessageText(sample.text);
    setRecruiterEmail(sample.recruiterEmail || '');
    setUrlOrDomain(sample.urlOrDomain || '');
  };

  const handleClear = () => {
    setActiveSampleId(null);
    setMessageText('');
    setRecruiterEmail('');
    setUrlOrDomain('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      if (messageText.trim().length > 0 && !isScanning) {
        onScan();
      }
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 transition-all">
      {/* Header and Quick Presets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-600" />
            Inspect Message, Offer Letter, or Email
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Paste suspicious job descriptions, interview chats, check notifications, or wire requests.
          </p>
        </div>

        {messageText.length > 0 && (
          <button
            id="btn-clear-inputs"
            onClick={handleClear}
            className="self-start sm:self-center inline-flex items-center gap-1 px-2.5 py-1 text-xs text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
            title="Clear all fields"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        )}
      </div>

      {/* Preset Samples Selector */}
      <div className="mb-4 bg-slate-50/80 p-3 rounded-xl border border-slate-200/70">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            Load Realistic Test Samples:
          </span>
          <span className="text-[11px] text-slate-600 hidden sm:inline">Click to instantly populate</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_CASES.map((sample) => {
            const isSelected = activeSampleId === sample.id;
            return (
              <button
                key={sample.id}
                id={`btn-sample-${sample.id}`}
                onClick={() => handleSelectSample(sample)}
                className={`text-xs px-2.5 py-1.5 rounded-lg border font-medium transition-all text-left flex items-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-amber-100/80 border-amber-300 text-amber-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
                }`}
              >
                {isSelected && <CheckCircle className="w-3 h-3 text-amber-700" />}
                <span>{sample.title}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                  sample.expectedRisk === 'CRITICAL' ? 'bg-rose-100 text-rose-700' :
                  sample.expectedRisk === 'HIGH' ? 'bg-orange-100 text-orange-700' :
                  'bg-emerald-100 text-emerald-700'
                }`}>
                  {sample.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Textarea */}
      <div className="relative mb-4">
        <textarea
          id="textarea-suspicious-text"
          value={messageText}
          onChange={(e) => {
            setMessageText(e.target.value);
            if (activeSampleId) setActiveSampleId(null);
          }}
          onKeyDown={handleKeyDown}
          placeholder="Paste suspicious text here... Example: 'Congratulations! You are hired for the Remote Data Entry position. A cashier's check of $4,850 will be sent for home equipment. Contact Dr. Robert on Telegram @ApexHR...'"
          rows={7}
          className="w-full px-4 py-3 text-sm text-slate-900 bg-slate-50/50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition-all font-mono leading-relaxed resize-y"
        />

        <div className="flex items-center justify-between text-[11px] text-slate-600 px-1 mt-1">
          <span>{messageText.length} characters &bull; {messageText.trim().split(/\s+/).filter(Boolean).length} words</span>
          <span className="hidden sm:inline text-slate-600">Press <kbd className="px-1 py-0.5 bg-slate-100 border border-slate-200 rounded text-[10px] text-slate-700">Cmd/Ctrl + Enter</kbd> to scan</span>
        </div>
      </div>

      {/* Optional Metadata Row (Recruiter Email & URL) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
        <div>
          <label htmlFor="input-recruiter-email" className="block text-xs font-semibold text-slate-700 mb-1.5">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-500" />
              Recruiter / Sender Email <span className="text-slate-600 font-normal">(Optional)</span>
            </span>
          </label>
          <input
            id="input-recruiter-email"
            type="email"
            value={recruiterEmail}
            onChange={(e) => setRecruiterEmail(e.target.value)}
            placeholder="e.g. hr.company@gmail.com or jobs@company-hr.top"
            className="w-full px-3.5 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition-all"
          />
        </div>

        <div>
          <label htmlFor="input-target-url" className="block text-xs font-semibold text-slate-700 mb-1.5">
            <span className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              Attached URL or Career Portal <span className="text-slate-600 font-normal">(Optional)</span>
            </span>
          </label>
          <input
            id="input-target-url"
            type="text"
            value={urlOrDomain}
            onChange={(e) => setUrlOrDomain(e.target.value)}
            placeholder="e.g. https://apex-solutions-careers.xyz/verify"
            className="w-full px-3.5 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition-all"
          />
        </div>
      </div>

      {/* Primary Action Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
        <p className="text-xs text-slate-500 flex items-center gap-1.5 text-center sm:text-left">
          <Shield className="w-3.5 h-3.5 text-amber-700 shrink-0" />
          <span>ScamShield evaluates 40+ fraud markers including advance-fee checks, Telegram interviews, & domain spoofing.</span>
        </p>

        <button
          id="btn-scan-threats"
          onClick={onScan}
          disabled={isScanning || messageText.trim().length === 0}
          className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-sm cursor-pointer ${
            isScanning || messageText.trim().length === 0
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
              : 'bg-slate-900 hover:bg-slate-800 text-amber-400 active:scale-98'
          }`}
        >
          {isScanning ? (
            <>
              <div className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
              <span>Scanning for Threats...</span>
            </>
          ) : (
            <>
              <Shield className="w-4 h-4 text-amber-400" />
              <span>Scan for Threats</span>
              <ArrowRight className="w-4 h-4 text-amber-400/80" />
            </>
          )}
        </button>
      </div>
    </div>
  );
}
