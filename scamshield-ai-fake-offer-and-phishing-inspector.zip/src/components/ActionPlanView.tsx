import { useState } from 'react';
import { ActionPlan } from '../types';
import { CheckSquare, ShieldCheck, XCircle, AlertTriangle, ExternalLink, Download, FileText, CheckCircle2 } from 'lucide-react';

interface ActionPlanViewProps {
  actionPlan: ActionPlan;
  onOpenReport: () => void;
}

export function ActionPlanView({ actionPlan, onOpenReport }: ActionPlanViewProps) {
  // Track checklist completion state for immediate steps
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});

  const toggleStep = (idx: number) => {
    setCompletedSteps(prev => ({
      ...prev,
      [idx]: !prev[idx]
    }));
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">
              What Should I Do Now? (Security Action Plan)
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Prescribed containment actions, safe verification methods, and official reporting channels.
          </p>
        </div>

        <button
          id="btn-generate-report-action-plan"
          onClick={onOpenReport}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-amber-400 font-semibold text-xs rounded-xl shadow-xs transition-colors self-start sm:self-center cursor-pointer"
        >
          <Download className="w-4 h-4 text-amber-400" />
          <span>Generate Downloadable Report</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        {/* Immediate Containment Steps (Interactive Checklist) */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wider">
              <CheckSquare className="w-4 h-4 text-emerald-600" />
              1. Immediate Containment Steps
            </span>
            <span className="text-[11px] text-slate-600">Click to track</span>
          </div>

          <div className="space-y-2.5">
            {actionPlan.immediateSteps.map((step, idx) => {
              const isChecked = !!completedSteps[idx];
              return (
                <div
                  key={idx}
                  onClick={() => toggleStep(idx)}
                  className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-start gap-2.5 select-none ${
                    isChecked
                      ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900'
                      : 'bg-white border-slate-200/90 text-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center shrink-0 border ${
                    isChecked ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                  }`}>
                    {isChecked && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                  <span className={`text-xs leading-relaxed ${isChecked ? 'line-through text-slate-600 font-normal' : 'font-medium'}`}>
                    {step}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Prohibited Actions: What NOT To Do */}
        <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/40">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5 uppercase tracking-wider">
              <XCircle className="w-4 h-4 text-rose-600" />
              2. Critical Prohibitions (Never Do This)
            </span>
            <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-rose-200 text-rose-900">
              High Risk
            </span>
          </div>

          <div className="space-y-2.5">
            {actionPlan.whatNotToDo.map((item, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg border border-rose-200/90 bg-white text-rose-950 flex items-start gap-2.5 shadow-2xs"
              >
                <div className="w-4 h-4 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
                  ✕
                </div>
                <span className="text-xs leading-relaxed font-medium">
                  {item}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Safe Independent Verification Methods */}
      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 mb-5">
        <div className="flex items-center gap-1.5 mb-2">
          <ShieldCheck className="w-4 h-4 text-sky-600" />
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            3. Safe Independent Verification Protocol
          </span>
        </div>
        <p className="text-xs text-slate-500 mb-3">
          How to verify this opportunity without relying on contact details supplied in the suspicious message:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {actionPlan.safeVerificationSteps.map((step, idx) => (
            <div key={idx} className="p-3 bg-white rounded-lg border border-slate-200 shadow-2xs text-xs text-slate-700 flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center shrink-0 text-[11px] font-bold">
                {idx + 1}
              </span>
              <span className="leading-relaxed">{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Official Incident Reporting Channels */}
      <div>
        <div className="flex items-center gap-1.5 mb-2">
          <AlertTriangle className="w-4 h-4 text-amber-600" />
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            4. Official Incident Reporting Portals
          </span>
        </div>
        <p className="text-xs text-slate-500 mb-3">
          Filing reports helps consumer protection agencies dismantle scam networks and freeze fraudulent recipient accounts:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {actionPlan.reportingChannels.map((channel, idx) => (
            <a
              key={idx}
              href={channel.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-xs transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="font-bold text-xs text-slate-900 group-hover:text-amber-800 transition-colors">
                    {channel.name}
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 transition-colors" />
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  {channel.description}
                </p>
              </div>
              <span className="text-[10px] text-amber-800 font-semibold mt-2 underline underline-offset-2">
                Visit Official Portal &rarr;
              </span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
