import { useState } from 'react';
import { ThreatAnalysisResult } from '../types';
import { generateHtmlReport, generateMarkdownReport, downloadFile } from '../utils/reportGenerator';
import { X, Download, Copy, Check, FileCode, Printer, Shield } from 'lucide-react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: ThreatAnalysisResult;
  inputSnippet: string;
}

export function ReportModal({ isOpen, onClose, result, inputSnippet }: ReportModalProps) {
  const [copied, setCopied] = useState(false);
  const [reportFormat, setReportFormat] = useState<'markdown' | 'html'>('markdown');

  if (!isOpen) return null;

  const markdownContent = generateMarkdownReport(result, inputSnippet);
  const htmlContent = generateHtmlReport(result, inputSnippet);

  const handleCopy = () => {
    navigator.clipboard.writeText(markdownContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const filename = `scamshield-threat-audit-${new Date().toISOString().slice(0, 10)}.md`;
    downloadFile(markdownContent, filename, 'text/markdown;charset=utf-8');
  };

  const handleDownloadHtml = () => {
    const filename = `scamshield-threat-audit-${new Date().toISOString().slice(0, 10)}.html`;
    downloadFile(htmlContent, filename, 'text/html;charset=utf-8');
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
      }, 350);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Shield className="w-4 h-4 text-amber-700" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Threat Audit & Incident Report
              </h2>
              <p className="text-xs text-slate-500">
                Score: {result.threatIndex}/100 &bull; Risk: {result.riskLevel} &bull; {result.scamCategory}
              </p>
            </div>
          </div>

          <button
            id="btn-close-report-modal"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              id="btn-download-html"
              onClick={handleDownloadHtml}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-400 font-semibold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download HTML Audit</span>
            </button>

            <button
              id="btn-download-md"
              onClick={handleDownloadMarkdown}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs rounded-lg border border-slate-200 shadow-2xs transition-colors cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5 text-slate-500" />
              <span>Download Markdown (.md)</span>
            </button>

            <button
              id="btn-print-report"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs rounded-lg border border-slate-200 shadow-2xs transition-colors cursor-pointer"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print / PDF</span>
            </button>
          </div>

          <button
            id="btn-copy-report-text"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-lg border border-slate-200 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700 font-semibold">Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-500" />
                <span>Copy Full Report</span>
              </>
            )}
          </button>
        </div>

        {/* Live Preview Pane */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs text-slate-800 bg-slate-900 text-slate-100 whitespace-pre-wrap select-all leading-relaxed max-h-[60vh]">
          {markdownContent}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500">
          <span>Official audit document suitable for filing with FTC, IC3, or HR compliance.</span>
          <button
            id="btn-modal-done"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-medium transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
