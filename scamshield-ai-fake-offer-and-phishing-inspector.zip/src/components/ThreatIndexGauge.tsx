import { ThreatAnalysisResult, RiskLevel } from '../types';
import { AlertTriangle, CheckCircle, ShieldAlert, ShieldCheck, Download, AlertOctagon, Share2, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface ThreatIndexGaugeProps {
  result: ThreatAnalysisResult;
  onOpenReport: () => void;
}

export function ThreatIndexGauge({ result, onOpenReport }: ThreatIndexGaugeProps) {
  const [copied, setCopied] = useState(false);

  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case 'CRITICAL':
        return {
          text: 'text-rose-700',
          bg: 'bg-rose-50',
          border: 'border-rose-200',
          badge: 'bg-rose-600 text-white',
          stroke: '#e11d48',
          gradientFrom: '#f43f5e',
          gradientTo: '#9f1239'
        };
      case 'HIGH':
        return {
          text: 'text-orange-700',
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          badge: 'bg-orange-600 text-white',
          stroke: '#ea580c',
          gradientFrom: '#fb923c',
          gradientTo: '#c2410c'
        };
      case 'MODERATE':
        return {
          text: 'text-amber-800',
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          badge: 'bg-amber-600 text-white',
          stroke: '#d97706',
          gradientFrom: '#fbbf24',
          gradientTo: '#b45309'
        };
      case 'LOW':
        return {
          text: 'text-sky-700',
          bg: 'bg-sky-50',
          border: 'border-sky-200',
          badge: 'bg-sky-600 text-white',
          stroke: '#0284c7',
          gradientFrom: '#38bdf8',
          gradientTo: '#0369a1'
        };
      case 'SAFE':
      default:
        return {
          text: 'text-emerald-700',
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          badge: 'bg-emerald-600 text-white',
          stroke: '#16a34a',
          gradientFrom: '#4ade80',
          gradientTo: '#15803d'
        };
    }
  };

  const colors = getRiskColor(result.riskLevel);

  // SVG Gauge calculations (semi-circle arc)
  const radius = 70;
  const strokeWidth = 14;
  const circumference = Math.PI * radius; // 180 degrees arc
  const strokeDashoffset = circumference - (result.threatIndex / 100) * circumference;

  const handleCopySummary = () => {
    const text = `ScamShield Threat Assessment:
Threat Index: ${result.threatIndex}/100 (${result.riskLevel})
Category: ${result.scamCategory}
Verdict: ${result.verdictTitle}
Summary: ${result.summary}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`rounded-2xl border ${colors.border} bg-white shadow-sm overflow-hidden transition-all`}>
      {/* Top Banner Alert Bar */}
      <div className={`px-5 py-3 ${colors.bg} border-b ${colors.border} flex flex-wrap items-center justify-between gap-3`}>
        <div className="flex items-center gap-2.5">
          {result.riskLevel === 'CRITICAL' || result.riskLevel === 'HIGH' ? (
            <ShieldAlert className={`w-5 h-5 ${colors.text} shrink-0`} />
          ) : result.riskLevel === 'MODERATE' ? (
            <AlertTriangle className={`w-5 h-5 ${colors.text} shrink-0`} />
          ) : (
            <ShieldCheck className={`w-5 h-5 ${colors.text} shrink-0`} />
          )}
          <span className={`text-xs font-bold uppercase tracking-wider ${colors.text}`}>
            Threat Level: {result.riskLevel}
          </span>
          <span className="text-slate-300">&bull;</span>
          <span className="text-xs font-medium text-slate-700">
            {result.scamCategory}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-copy-summary"
            onClick={handleCopySummary}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white/80 hover:bg-white rounded-lg border border-slate-200 transition-colors cursor-pointer"
            title="Copy summary"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-500" />
                <span>Copy Summary</span>
              </>
            )}
          </button>

          <button
            id="btn-open-report-top"
            onClick={onOpenReport}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Generate Report</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Gauge Meter Col */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 bg-slate-50/70 rounded-xl border border-slate-100">
            <div className="relative w-48 h-28 flex flex-col items-center justify-end">
              <svg className="w-48 h-28 overflow-visible" viewBox="0 0 180 100">
                <defs>
                  <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="35%" stopColor="#0ea5e9" />
                    <stop offset="65%" stopColor="#f59e0b" />
                    <stop offset="85%" stopColor="#f97316" />
                    <stop offset="100%" stopColor="#e11d48" />
                  </linearGradient>
                </defs>

                {/* Background Arc */}
                <path
                  d="M 20 90 A 70 70 0 0 1 160 90"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth={strokeWidth}
                  strokeLinecap="round"
                />

                {/* Progress Value Arc */}
                <path
                  d="M 20 90 A 70 70 0 0 1 160 90"
                  fill="none"
                  stroke="url(#gaugeGradient)"
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
              </svg>

              {/* Central Threat Score Text */}
              <div className="absolute inset-0 flex flex-col items-center justify-end pb-1 pointer-events-none">
                <span className="text-4xl font-black text-slate-900 tracking-tight leading-none">
                  {result.threatIndex}
                </span>
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mt-0.5">
                  Threat Index / 100
                </span>
              </div>
            </div>

            {/* Risk Badge */}
            <div className="mt-3 flex items-center gap-1.5">
              <span className={`px-3 py-1 rounded-full text-xs font-black tracking-wide uppercase ${colors.badge} shadow-2xs`}>
                {result.riskLevel} RISK
              </span>
            </div>

            <div className="flex justify-between w-full text-[10px] text-slate-600 px-3 mt-3 border-t border-slate-200/60 pt-2 font-medium">
              <span>0 Safe</span>
              <span>40 Moderate</span>
              <span>80+ Critical</span>
            </div>
          </div>

          {/* Verdict and Summary Text */}
          <div className="lg:col-span-8 flex flex-col justify-center">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Threat Inspector Verdict
              </span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 leading-snug mb-3">
              {result.verdictTitle}
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              {result.summary}
            </p>

            {/* Quick Indicators Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-3 border-t border-slate-100">
              {result.indicators.slice(0, 4).map((ind, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-lg border text-xs flex items-start gap-2 ${
                    ind.present
                      ? 'bg-rose-50/60 border-rose-200 text-rose-900'
                      : 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                  }`}
                >
                  {ind.present ? (
                    <AlertOctagon className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{ind.indicator}</div>
                    <div className="text-[11px] opacity-80 line-clamp-1">{ind.observation}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
