import { useState } from 'react';
import { ShieldCheck, ShieldAlert, Info, Lock, HelpCircle, X, CheckCircle2 } from 'lucide-react';

export function Header() {
  const [showInfoModal, setShowInfoModal] = useState(false);

  return (
    <header className="border-b border-slate-200/80 bg-white/95 backdrop-blur sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center shadow-inner">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-slate-900 tracking-tight">ScamShield AI</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold border border-amber-200/60">
                Threat Inspector
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Fake Offer & Phishing Intelligence Engine
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-500 bg-slate-100/90 py-1.5 px-3 rounded-full border border-slate-200">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Private Server Analysis &bull; Keys Protected</span>
          </div>

          <button
            id="btn-how-it-works"
            onClick={() => setShowInfoModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline">How It Works</span>
          </button>
        </div>
      </div>

      {/* Info Modal */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
            <button
              id="btn-close-info-modal"
              onClick={() => setShowInfoModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
                <Info className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">How ScamShield AI Inspects Threats</h2>
            </div>

            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              ScamShield AI utilizes state-of-the-art Gemini deep intelligence to inspect text, job offers, email headers, and URLs for social engineering and fraudulent mechanisms:
            </p>

            <div className="space-y-3 mb-6 text-xs text-slate-700">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Linguistic Coercion & Urgency Detection:</strong>
                  <span className="text-slate-600"> Unmasks high-pressure deadlines, threats of payroll freezes, and artificial scarcity.</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Advance-Fee & Check Schemes:</strong>
                  <span className="text-slate-600"> Detects counterfeit check schemes, "home office equipment vendor" orders, and requests for cashier checks.</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Off-Platform Channel Anomalies:</strong>
                  <span className="text-slate-600"> Identifies recruiters directing applicants to anonymous apps (Telegram, WhatsApp, Signal) or free webmail (@gmail.com).</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900">Domain & URL Verification:</strong>
                  <span className="text-slate-600"> Inspects domain structure, typosquatting (e.g. google-verify.xyz), free form services, and suspicious TLDs.</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                id="btn-understand-info-modal"
                onClick={() => setShowInfoModal(false)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
