export type RiskLevel = 'SAFE' | 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface HighlightedPhrase {
  phrase: string;
  category: string;
  severity: 'high' | 'medium' | 'low';
  explanation: string;
}

export interface UrlFindings {
  detectedUrl?: string;
  verdict: 'safe' | 'suspicious' | 'malicious' | 'unverified' | 'none';
  domainAnalysis: string;
  details: string[];
}

export interface EmailFindings {
  detectedEmail?: string;
  verdict: 'safe' | 'suspicious' | 'spoofed' | 'unverified' | 'none';
  domainAnalysis: string;
  details: string[];
}

export interface ReportingChannel {
  name: string;
  description: string;
  url: string;
}

export interface ActionPlan {
  immediateSteps: string[];
  safeVerificationSteps: string[];
  whatNotToDo: string[];
  reportingChannels: ReportingChannel[];
}

export interface ScamIndicator {
  indicator: string;
  present: boolean;
  scoreImpact: number;
  observation: string;
}

export interface ThreatAnalysisResult {
  threatIndex: number; // 0 to 100
  riskLevel: RiskLevel;
  verdictTitle: string;
  summary: string;
  scamCategory: string;
  highlightedPhrases: HighlightedPhrase[];
  urlFindings: UrlFindings;
  emailFindings: EmailFindings;
  actionPlan: ActionPlan;
  indicators: ScamIndicator[];
  analyzedAt: string;
  inputExcerpt: {
    textLength: number;
    hasUrl: boolean;
    hasEmail: boolean;
  };
}

export interface ScanRequest {
  messageText: string;
  urlOrDomain?: string;
  recruiterEmail?: string;
}
