export interface SampleCase {
  id: string;
  title: string;
  badge: string;
  expectedRisk: string;
  recruiterEmail?: string;
  urlOrDomain?: string;
  text: string;
}

export const SAMPLE_CASES: SampleCase[] = [
  {
    id: "equipment-check",
    title: "Fake Remote Job & Equipment Check",
    badge: "Most Common",
    expectedRisk: "CRITICAL",
    recruiterEmail: "recruitment.apexsolutions.hr@gmail.com",
    urlOrDomain: "http://apex-solutions-careers.xyz/verify",
    text: `Dear Candidate,

Congratulations! After reviewing your resume on Indeed, our hiring committee at Apex Global Solutions Inc. has unanimously selected you for the position of Senior Remote Data Entry / Operations Associate.

The hourly pay is $48.50/hour during training and $62.00/hour thereafter. This position is 100% remote with flexible hours.

To proceed with your onboarding and orientation:
1. You are required to connect immediately with our Senior Talent Director, Dr. Robert Morgan, on Telegram using the handle @ApexHR_Robert for your final briefing.
2. A cashier's check in the amount of $4,850.00 will be overnighted to your residential address. You must deposit this check to purchase equipment (Apple MacBook Pro, encrypted router, and specialized data portal software) from our certified vendor.
3. Once the check arrives, you must immediately deposit it via mobile deposit, keep $200 as your sign-on bonus, and wire transfer the remaining balance to our vendor via Zelle or cryptocurrency within 24 hours so your workstation can be dispatched.

Please confirm your full legal name, home address, mobile number, and your direct bank name so we can issue the check today. Immediate start is expected next Monday.

Sincerely,
Dr. Robert Morgan
Chief Talent Acquisition Specialist
Apex Global Solutions Inc.`
  },
  {
    id: "phishing-payroll",
    title: "Urgent Executive Phishing / Direct Deposit",
    badge: "Phishing",
    expectedRisk: "HIGH",
    recruiterEmail: "ceo-office@company-hr-portal.top",
    urlOrDomain: "https://auth-update-directdeposit.top/login",
    text: `URGENT NOTICE: Mandatory Payroll System Migration

All employees must verify and update their direct deposit banking credentials before 5:00 PM today due to our Q3 financial software migration. Failure to update within 24 hours will result in your upcoming paycheck being placed on administrative freeze.

Click the secure portal link below to log in with your corporate email password and submit the front and back of your ID along with your bank routing number:
https://auth-update-directdeposit.top/login

Do not forward this message. This is an automated security measure from Human Resources.

HR & Payroll Compliance Department`
  },
  {
    id: "whatsapp-crypto-task",
    title: "WhatsApp Task & Crypto Commission Scam",
    badge: "Social Scam",
    expectedRisk: "CRITICAL",
    recruiterEmail: "hr-agent99@outlook.com",
    urlOrDomain: "https://global-app-booster-vip.xyz",
    text: `Hello! I am Emma from Global Talent Partner. Are you looking for a flexible part-time online job using only your smartphone?

You can easily earn $300 to $800 daily by simply reviewing hotel bookings and optimizing app store ratings. The work takes only 30 to 60 minutes per day with daily payouts!

No experience required. Immediate start today.
To begin your first trial task, contact our customer service manager on WhatsApp at +1 (928) 492-0199 or Telegram @VIP_Task_Assistant.

Note: You will be credited 50 USDT crypto bonus into your account right after your first set of 30 product ratings. Contact us now to reserve your spot as openings are limited!`
  },
  {
    id: "legitimate-offer",
    title: "Verified Legitimate Tech Offer Letter",
    badge: "Legitimate Baseline",
    expectedRisk: "SAFE",
    recruiterEmail: "sarah.chen@acmecloud.com",
    urlOrDomain: "https://careers.acmecloud.com/jobs/REQ-84920",
    text: `Dear Alex,

We are delighted to extend an offer of employment for the position of Senior Frontend Engineer at Acme Cloud Technologies, Inc.

This offer is contingent upon standard background checks and verification of work authorization.
- Starting Base Salary: $145,000 annualized, paid semi-monthly.
- Equity: 15,000 stock options subject to standard 4-year vesting with a 1-year cliff.
- Health, Dental, and 401(k) match as detailed in the attached benefits summary.
- Anticipated Start Date: October 14, 2026.

All equipment (company-provisioned laptop and monitor) will be configured by Acme Cloud IT and shipped directly to your residential address with no expense to you.

Please review and electronically sign this formal offer letter via your existing Acme Cloud candidate portal at https://careers.acmecloud.com/jobs/REQ-84920 by October 5, 2026.

If you have questions, please reach out to me directly at sarah.chen@acmecloud.com or contact our hiring manager Mark Johnson.

Warm regards,
Sarah Chen
Senior Technical Recruiter | Acme Cloud Technologies, Inc.`
  }
];
